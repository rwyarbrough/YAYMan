/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package yayman;

/**
 *
 * @author Nordin
 */
public class NetworkedMediaTank {
    private String name;
    private String address;

    public NetworkedMediaTank() {
        name = "";
        address = "";
    }

    public NetworkedMediaTank(String n) {
        this();
        name = n;
    }

    public NetworkedMediaTank(String n, String a) {
        name = n;
        address = a;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public void setName(String s) {
        name = s;
    }

    public void setAddress(String s) {
        address = s;
    }

    @Override
    public String toString() {
        return name;
    }
}
